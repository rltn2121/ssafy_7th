package board.service;

import board.dto.UserDto;

public interface UserService {
	public UserDto register(String userName, String userEmail, String userPassword);
}
