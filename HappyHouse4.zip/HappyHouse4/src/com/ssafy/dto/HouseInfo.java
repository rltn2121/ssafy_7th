package com.ssafy.dto;

public class HouseInfo {

}
